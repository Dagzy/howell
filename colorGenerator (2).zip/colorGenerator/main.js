var r,g,b,cstring;
function colapply(){
color();

r=newcolor.slice(1,3);
g=newcolor.slice(3,5);
b=newcolor.slice(5,7);
r=parseInt(r,16);
g=parseInt(g,16);
b=parseInt(b,16);
	
cstring="rgb("+r+","+g+","+b+")";
$(".colorc").html("IDOC Search Protocol");
$("body").css({
"background":newcolor
});
$(".colorc").css({
"color":newcolor
});
 

 
}
var newcolor;
function color() {
    if (Math.random() < 0.13) {
      document.getElementById("green").classList.add("green");
      document.getElementById("red").classList.remove("red");
       // 10% of the time
       newcolor = '#ff0000'
       return;
     }else 
     document.getElementById("red").classList.add("red");
     document.getElementById("green").classList.remove("green");
     newcolor = "#6ec34c"
    
    
 }

 $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})

$(".colorc").click(colapply);
colapply();

 